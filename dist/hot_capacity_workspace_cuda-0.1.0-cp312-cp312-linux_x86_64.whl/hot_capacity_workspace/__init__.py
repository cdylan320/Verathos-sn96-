"""Verathos hot-capacity audit runtime harness."""
