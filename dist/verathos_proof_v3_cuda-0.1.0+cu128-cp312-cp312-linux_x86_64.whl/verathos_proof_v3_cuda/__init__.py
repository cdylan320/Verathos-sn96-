"""Load precompiled proof-v3 CUDA prover kernels."""

from __future__ import annotations

from importlib import import_module


def load_tree_kernels():
    return import_module(".gl_sha256_tree_v2", __name__)


def load_fused_kernels():
    return import_module(".gl_sumcheck_kernels", __name__)


__all__ = ["load_fused_kernels", "load_tree_kernels"]
